package com.example.checkpoint1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_calculadora.*

class Calculadora : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)


        var btnCalcularOperacao = findViewById<Button>(R.id.btnCalcular)
        btnCalcularOperacao.setOnClickListener { _: View? ->
            val txtn1 : Int = findViewById<EditText>(R.id.txtNumero1).text.toString().toInt()
            val txtn2 : Int = findViewById<EditText>(R.id.txtNumero2).text.toString().toInt()


            var resultado = 0

            if (rdbSoma.isChecked()) {
                resultado = txtn1+txtn2
            }
            else if (rdbSubtracao.isChecked()) {
                resultado = txtn1-txtn2
            }
            else if (rdbMultiplicacao.isChecked()) {
                resultado = txtn1*txtn2
            }
            else if (rdbDivisao.isChecked()) {
                resultado = txtn1/txtn2
            }
            Toast.makeText(this, resultado.toString(), Toast.LENGTH_LONG).show()

        }
    }
}