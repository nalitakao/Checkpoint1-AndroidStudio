package com.example.checkpoint1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_conta_telefonica.*

class ContaTelefonica : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conta_telefonica)

        btnCalcularConta.setOnClickListener {
            var assinatura = txtAssinatura.text.toString().toDouble()
            var minLocal = txtMinLocal.text.toString().toDouble() * 0.04
            var minCel = txtMinCel.text.toString().toDouble() * 0.2

            var totalConta : Double = assinatura + minLocal + minCel


            var proxIntent = Intent(this, ValorConta::class.java)
            proxIntent.putExtra("ass", assinatura.toString())
            proxIntent.putExtra("local", minLocal.toString())
            proxIntent.putExtra("celular", minCel.toString())
            proxIntent.putExtra("total", totalConta.toString())

            startActivity(proxIntent)
        }


    }
}