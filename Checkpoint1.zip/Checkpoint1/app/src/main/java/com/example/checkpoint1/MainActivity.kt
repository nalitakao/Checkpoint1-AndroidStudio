package com.example.checkpoint1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fun alert(titulo : String, mensagem : String) {
            val builder = AlertDialog.Builder(this)
            builder
                .setTitle(titulo)
                .setMessage(mensagem)
                .setPositiveButton("Ok", null)
            builder.create().show()
        }

        btnIntegrantes.setOnClickListener {
            var msg = """RM86358 – BIANCA NUNES FERRAZ CABRAL
                |RM86350 - MICAELA MOTA SANTOS
                |RM84530 - NALITA TSU KAO
            """.trimMargin("|")

            alert("Desenvolvido por", msg)
        }

        btnCalculadora.setOnClickListener {
            val intentCalculadora = Intent(this, Calculadora::class.java)
            startActivity(intentCalculadora)
        }

        btnConta.setOnClickListener {
            val intentConta = Intent(this, ContaTelefonica::class.java)
            startActivity(intentConta)
        }
    }
}