package com.example.checkpoint1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_valor_conta.*

class ValorConta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_valor_conta)

        lbAssinatura.text = intent.getStringExtra("ass")
        lbLocal.text = intent.getStringExtra("local")
        lbCelular.text = intent.getStringExtra("celular")
        lbTotalConta.text = intent.getStringExtra("total")
    }
}